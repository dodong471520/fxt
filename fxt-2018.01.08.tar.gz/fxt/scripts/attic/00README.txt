This directory (attic/) contains material
that is not (anymore) part of the FXT library
but may still be useful.

