//  for f in src/*-all.h; do echo '#include "'$(basename $f)'"'; done

#include "aux0-all.h"
#include "aux1-all.h"
#include "aux2-all.h"
#include "bits-all.h"
#include "bmat-all.h"
#include "bpol-all.h"
#include "chirpzt-all.h"
#include "convolution-all.h"
#include "correlation-all.h"
#include "dctdst-all.h"
#include "ds-all.h"
#include "fft-all.h"
#include "fht-all.h"
#include "graph-all.h"
#include "haar-all.h"
#include "matrix-all.h"
#include "mod-all.h"
#include "ntt-all.h"
#include "perm-all.h"
#include "realfft-all.h"
#include "sort-all.h"
#include "walsh-all.h"
#include "wavelet-all.h"
#include "comb-all.h"

int main()
{
    return 0;
}
// -------------------------

